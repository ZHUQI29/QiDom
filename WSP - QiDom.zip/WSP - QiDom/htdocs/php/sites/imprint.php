<div class="container impressum">
  <div class="container-md mt-4 text-white-50 box-1 px-3 py-2">
    <div id="headline">
      <h1 class="display-2">Impressum</h1>
    </div>
    <div>
      <h3 class="qd-text-col-main pt-2"><u>QiDom AG</u></h3>
    </div>
    <div>
      <p><b>Geschäftsführung</b></p>
    </div>
    <div>
      <p>Qi Zhu<br>Artjom Moisejev</p>
    </div>
    <div>
      <p>Höchstädtplatz 0<br>1200 Wien<br>T: +43 660 8654-314<br>F: +43 1 420 69-69<br><a href="mailto:if21b206@technikum-wien.at" class="qd-text-col-secondary">if21b206@technikum-wien.at</a><br><a href="mailto:if21b055@technikum-wien.at" class="qd-text-col-secondary">if21b055@technikum-wien.at</a></p>
    </div>
    <div>
      <p>UID-Nummer: ATU12345678</p>
    </div>
    <div class="container">
      <img src="/img/team/random-team.png" alt="Team Photo" class="team-img">
    </div>
    <div>
      <p>Offenlegungspflicht gemäß § 25 Mediengesetz und Informationspflicht gemäß § 5 E-Commerce-Gesetz:<br>Medieninhaber und Herausgeber</p>
    </div>
    <div>
      <a href="index.php?site=faq" class="qd-text-col-main">FAQ</a>
    </div>
    <br>
  </div>
</div>
