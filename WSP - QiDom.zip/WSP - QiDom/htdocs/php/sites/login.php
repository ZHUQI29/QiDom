<div class="login-container">
  <form name="login" action="db-login.php" method="POST">
      <h3>username<input type=text name="username"></h3>
      <h3>password<input type=password name="password"></h3>
      <br>
      <input class="submit-button" type="submit" name="login" value="LOGIN">
  </form>
  <form class="container-fluid" action="index.php?site=registration" method="post">
      <input class="submit-button" type="submit" name="" value="Registration">
  </form>
</div>
