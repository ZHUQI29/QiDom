<div class="container-md my-5">
  <div class="box-1 px-5 py-3">
    <h1>Zufrieden? Fragen?</h1>
    <br>
    <p>Im <a href='index.php?site=faq'>FAQ</a> findest du Hilfestellung bei der Bedienung der Website, der Zimmergeräte und Vieles mehr!</p>
    <br>
    <p>Bei einem technischen Defekt, kannst du ein <a href='index.php?site=tickets'>Ticket</a> erstellen. Danke für deine Mithilfe! :)</p>
    <br>
    <p>Solltest du noch weitere Fragen haben, dann kontaktiere uns! <br><a href='index.php?site=imprint'>Impressum</a></p>
  </div>
</div>
