<div class="login-container welcome-con">
  <h1><a class="submit-button container" style="text-decoration: none;" href='index.php?site=home'>Welcome, <?php echo $_COOKIE['user'] ?></a></h1>
</div>
