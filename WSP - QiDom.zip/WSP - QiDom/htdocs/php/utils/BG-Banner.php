<div class="banner">
  <img src="../img/banner.png" alt="cool banner" class="img-fluid">
</div>
