<br>
<label for="status">Status: </label>
<br>
<select name="status">
  <option value="0">BAN</option>
  <option value="1" selected >Gast</option>
  <option value="2">Technik</option>
  <option value="3">Admin</option>
</select>
<br>
